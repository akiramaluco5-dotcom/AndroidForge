# CapaLab FF — projeto Android do zero

Aplicativo independente de treino e organização de sensibilidade para Android.

## Incluído
- Interface escura com destaque verde neon.
- Navegação Início / Sensibilidade / Treino / Perfis.
- Sliders para Geral, Ponto vermelho, 2x, 4x, AWM e Olhadinha.
- Treinador de alvos com pontuação e precisão.
- Gerenciador de perfis básico.

## Compilar APK
1. Instale Android Studio: https://developer.android.com/studio
2. Extraia o ZIP e abra a pasta `CapaLabFF-do-zero`.
3. Aguarde a sincronização Gradle e instale o Android SDK 35 se solicitado.
4. Escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK de debug esperado: `app/build/outputs/apk/debug/app-debug.apk`.

## Limites
Este projeto não inclui aimbot, ESP, manipulação de memória ou edição de arquivos do Free Fire. Não aplica configurações automaticamente ao jogo. Os perfis desta versão são temporários e ficam na memória durante a sessão.
