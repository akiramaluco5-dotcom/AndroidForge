package com.capalabff

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val BG = Color(0xFF090C0F)
private val CARD = Color(0xFF151B20)
private val LIME = Color(0xFFB8FF32)
private val SUB = Color(0xFF9AA7AE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CapaLab() }
    }
}

@Composable
fun CapaLab() {
    var page by remember { mutableStateOf("Início") }
    var general by remember { mutableFloatStateOf(180f) }
    var redDot by remember { mutableFloatStateOf(170f) }
    var scope2x by remember { mutableFloatStateOf(155f) }
    var scope4x by remember { mutableFloatStateOf(140f) }
    var awm by remember { mutableFloatStateOf(90f) }
    var freeLook by remember { mutableFloatStateOf(120f) }
    var profile by remember { mutableStateOf("Equilibrado") }
    var savedProfiles by remember { mutableStateOf(listOf("Equilibrado")) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = LIME, onPrimary = BG, background = BG, surface = CARD,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = BG,
            bottomBar = {
                NavigationBar(containerColor = CARD) {
                    listOf("Início", "Sensibilidade", "Treino", "Perfis").forEach { p ->
                        NavigationBarItem(
                            selected = page == p,
                            onClick = { page = p },
                            icon = { Text(when (p) { "Início" -> "⌂"; "Sensibilidade" -> "◎"; "Treino" -> "⊙"; else -> "▤" }, fontSize = 20.sp) },
                            label = { Text(p, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = LIME, selectedTextColor = LIME,
                                indicatorColor = Color(0xFF29371A),
                                unselectedIconColor = SUB, unselectedTextColor = SUB
                            )
                        )
                    }
                }
            }
        ) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(15.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("♛ CAPALAB FF", color = LIME, fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("TREINO • SENSIBILIDADE • PERFIS", color = SUB, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                    Text("v1.0", color = LIME, fontSize = 11.sp)
                }
                when (page) {
                    "Início" -> {
                        Text("Domine sua mira.", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 32.sp)
                        Text("Treine sua precisão e encontre ajustes que funcionem para você.", color = SUB, fontSize = 14.sp)
                        CardPanel {
                            Text("PERFIL ATUAL", color = LIME, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text(profile, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("Geral: ${general.toInt()}  •  Ponto vermelho: ${redDot.toInt()}", color = SUB, fontSize = 12.sp)
                            Button(onClick = { page = "Sensibilidade" }, modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = LIME, contentColor = BG)) {
                                Text("AJUSTAR SENSIBILIDADE", fontWeight = FontWeight.Bold)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FeatureCard("◎", "Treino de mira", "Alvos e pontuação", Modifier.weight(1f)) { page = "Treino" }
                            FeatureCard("▤", "Perfis", "Salvar configurações", Modifier.weight(1f)) { page = "Perfis" }
                        }
                        CardPanel {
                            Text("ROTINA RECOMENDADA", color = LIME, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
                            Text("01  Treine por 3 a 5 minutos\n02  Mude apenas um ajuste de cada vez\n03  Compare os resultados no campo de treino", fontSize = 13.sp, lineHeight = 23.sp)
                        }
                        Text("Ferramenta independente: não injeta código no jogo nem automatiza mira ou revela jogadores.", color = SUB, fontSize = 11.sp)
                    }
                    "Sensibilidade" -> {
                        Text("Sensibilidade", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Valores são pontos de partida. Ajuste gradualmente e confira os limites disponíveis no jogo.", color = SUB, fontSize = 12.sp)
                        SensControl("Geral", general) { general = it }
                        SensControl("Ponto vermelho", redDot) { redDot = it }
                        SensControl("Mira 2x", scope2x) { scope2x = it }
                        SensControl("Mira 4x", scope4x) { scope4x = it }
                        SensControl("Mira AWM", awm) { awm = it }
                        SensControl("Olhadinha", freeLook) { freeLook = it }
                        Button(onClick = {
                            general = 180f; redDot = 170f; scope2x = 155f
                            scope4x = 140f; awm = 90f; freeLook = 120f
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = LIME, contentColor = BG)) {
                            Text("RESTAURAR PADRÃO INICIAL", fontWeight = FontWeight.Bold)
                        }
                    }
                    "Treino" -> AimPractice()
                    else -> {
                        Text("Meus perfis", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Salve um retrato das suas configurações nesta sessão.", color = SUB, fontSize = 12.sp)
                        CardPanel {
                            Text("PERFIL SELECIONADO", color = LIME, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(profile, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("Geral ${general.toInt()} • Red dot ${redDot.toInt()} • 2x ${scope2x.toInt()} • 4x ${scope4x.toInt()}", color = SUB, fontSize = 12.sp)
                            OutlinedTextField(
                                value = profile, onValueChange = { profile = it },
                                label = { Text("Nome do perfil") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = LIME, focusedLabelColor = LIME, cursorColor = LIME
                                )
                            )
                            Button(onClick = {
                                val name = profile.trim().ifBlank { "Meu perfil" }
                                profile = name
                                if (name !in savedProfiles) savedProfiles = savedProfiles + name
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = LIME, contentColor = BG)) {
                                Text("SALVAR PERFIL", fontWeight = FontWeight.Bold)
                            }
                        }
                        savedProfiles.forEach { name ->
                            CardPanel {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(name, fontWeight = FontWeight.Bold)
                                        Text(if (name == profile) "Selecionado" else "Perfil disponível", color = SUB, fontSize = 11.sp)
                                    }
                                    TextButton(onClick = { profile = name }) { Text("USAR", color = LIME) }
                                }
                            }
                        }
                        Text("Observação: nesta versão inicial os perfis ficam na memória enquanto o app está aberto; armazenamento permanente é uma melhoria futura.", color = SUB, fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun CardPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(CARD, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp), content = content
    )
}

@Composable
fun FeatureCard(symbol: String, title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.background(CARD, RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(symbol, color = LIME, fontSize = 25.sp)
        Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(subtitle, color = SUB, fontSize = 11.sp)
    }
}

@Composable
fun SensControl(title: String, value: Float, onChange: (Float) -> Unit) {
    CardPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Text(value.toInt().toString(), color = LIME, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = value, onValueChange = onChange, valueRange = 0f..200f,
            colors = SliderDefaults.colors(thumbColor = LIME, activeTrackColor = LIME, inactiveTrackColor = Color(0xFF384047)))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0", color = SUB, fontSize = 10.sp)
            Text("200", color = SUB, fontSize = 10.sp)
        }
    }
}

@Composable
fun AimPractice() {
    var active by remember { mutableStateOf(false) }
    var hits by remember { mutableIntStateOf(0) }
    var taps by remember { mutableIntStateOf(0) }
    var target by remember { mutableStateOf(Offset(0.5f, 0.5f)) }

    Text("Treino de mira", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
    Text("Toque no alvo verde dentro da área. Cada toque no alvo conta como acerto; tocar fora conta como tentativa.", color = SUB, fontSize = 12.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MiniStat("ACERTOS", hits.toString(), Modifier.weight(1f))
        MiniStat("TOQUES", taps.toString(), Modifier.weight(1f))
        MiniStat("PRECISÃO", if (taps == 0) "—" else "${hits * 100 / taps}%", Modifier.weight(1f))
    }
    CardPanel {
        BoxWithConstraints(
            Modifier.fillMaxWidth().height(330.dp).background(Color(0xFF0D1216), RoundedCornerShape(14.dp))
        ) {
            val w = maxWidth
            val h = maxHeight
            Canvas(Modifier.fillMaxSize()) {
                val gap = 32.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(Color(0xFF202A30), Offset(x, 0f), Offset(x, size.height), 1f)
                    x += gap
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(Color(0xFF202A30), Offset(0f, y), Offset(size.width, y), 1f)
                    y += gap
                }
                if (active) {
                    val center = Offset(target.x * size.width, target.y * size.height)
                    drawCircle(LIME.copy(alpha = 0.2f), 28.dp.toPx(), center)
                    drawCircle(LIME, 18.dp.toPx(), center)
                    drawCircle(BG, 7.dp.toPx(), center)
                }
            }
            if (active) {
                Box(
                    Modifier.offset(x = w * target.x - 28.dp, y = h * target.y - 28.dp)
                        .size(56.dp)
                        .clickable {
                            hits++
                            taps++
                            target = Offset(Random.nextFloat() * 0.76f + 0.12f, Random.nextFloat() * 0.72f + 0.14f)
                        }
                )
                Box(Modifier.fillMaxSize().clickable {
                    taps++
                    target = Offset(Random.nextFloat() * 0.76f + 0.12f, Random.nextFloat() * 0.72f + 0.14f)
                })
            } else {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("PRONTO?", color = LIME, fontWeight = FontWeight.Bold)
                    Text("Inicie o treino para exibir alvos", color = SUB, fontSize = 11.sp)
                }
            }
        }
        Button(onClick = {
            if (active) active = false else {
                active = true
                target = Offset(Random.nextFloat() * 0.76f + 0.12f, Random.nextFloat() * 0.72f + 0.14f)
            }
        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = LIME, contentColor = BG)) {
            Text(if (active) "ENCERRAR TREINO" else "INICIAR TREINO", fontWeight = FontWeight.Bold)
        }
        OutlinedButton(onClick = { active = false; hits = 0; taps = 0 }, modifier = Modifier.fillMaxWidth()) {
            Text("ZERAR RESULTADOS", color = LIME)
        }
    }
    Text("O treinador funciona dentro do aplicativo e não interage com o Free Fire.", color = SUB, fontSize = 11.sp)
}

@Composable
fun MiniStat(label: String, value: String, modifier: Modifier) {
    Column(modifier.background(CARD, RoundedCornerShape(13.dp)).padding(11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = SUB, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = LIME, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
    }
}
